//
//  ViewController.swift
//  core_data
//
//  Created by iroid on 09/11/21.
//  Copyright © 2021 iroid. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    @IBOutlet weak var stu_name: UITextField!
    @IBOutlet weak var stu_age: UITextField!
    @IBOutlet weak var stu_branch: UITextField!
    
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func save(_ sender: Any) {
        
        
        let student = NSEntityDescription.insertNewObject(forEntityName: "Student_details", into: context)
        student.setValue(self.stu_name.text, forKey: "name")
        student.setValue(self.stu_age.text, forKey: "age")
        student.setValue(self.stu_branch.text, forKey: "branch")
        
        do{
            try context.save()
            self.stu_name.text = ""
            self.stu_age.text = ""
            self.stu_branch.text = ""
            
        }catch{
            print("Erorr.......!")
        }
        
    }
    @IBAction func show_btn(_ sender: Any) {
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let stroryb = storyboard.instantiateViewController(withIdentifier: "secview") as! sec_ViewController
        self.navigationController?.pushViewController(stroryb, animated: true)
    
        }

}
