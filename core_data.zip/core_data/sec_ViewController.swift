//
//  sec_ViewController.swift
//  core_data
//
//  Created by iroid on 11/11/21.
//  Copyright © 2021 iroid. All rights reserved.
//

import UIKit

class sec_ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var studentt : [Student_details] = []
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return studentt.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tvcell", for: indexPath)
        let records = studentt[indexPath.row]
        //add the details to cell by record
        
        cell.textLabel?.text = records.name! + "" + records.age! + "" + records.branch!
       return cell
    }
    // delete the data using swipe
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        //share the container to perfome object-to-object communnication(.delegate)
        
        let context = (UIApplication.shared.delegate as!AppDelegate).persistentContainer.viewContext
        if editingStyle == .delete {
            let std = studentt[indexPath.row]
            context.delete(std) //delete the data
            (UIApplication.shared.delegate as! AppDelegate).saveContext()//save the data
            do{
                studentt = try context.fetch(Student_details.fetchRequest())
            }catch{
                print("Error.....!")
            }
            
        }//after the delete reload the beloving data
        tableView.reloadData()
        
        
    
    }
    //fetch the data
    func fetchdata() {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        do {
           studentt = try context.fetch(Student_details.fetchRequest())
        } catch  {
            print("Error...!")
        }
        
    }
    
    
    @IBOutlet weak var tvieww: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //add the  fetch data & reload
  self.fetchdata()
        self.tvieww.reloadData()
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
