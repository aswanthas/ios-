//
//  sec ViewController.swift
//  coredata_save_show_data
//
//  Created by iroid on 10/11/21.
//  Copyright © 2021 iroid. All rights reserved.
//

import UIKit

class sec_ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
